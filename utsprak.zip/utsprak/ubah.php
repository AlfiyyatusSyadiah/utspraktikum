<?php

include 'layout/header.php';

$id_promo = (int)$_GET['id_promo'];

$promo = select("SELECT * FROM promo WHERE id_promo = $id_promo")[0];

if (isset($_POST['ubah'])){
    if (update_promo($_POST) > 0){
        echo "<script>
                alert('Data Promo Berhasil Diubah');
                document.location.href = 'index.php';
              </script>";
    } else{
        echo "<script>
                alert('Data Promo Gagal Diubah');
                document.location.href = 'index.php';
              </script>";
    }
}

?>

<div class="container mt-5">
    <h1>Ubah Promo</h1>
    <hr>

    <form action="" method="post">

        <input type="hidden" name="id_promo" value="<?= $promo['id_promo']; ?>" >

        <div class="mb-3">
            <label for="nama_promo" class="form-label">Nama Promo</label>
            <input type="text" class="form-control" id="nama_promo" name="nama_promo" value="<?php echo $promo['nama_promo']; ?>" placeholder="Nama Promo ..." required>
        </div>

        <div class="mb-3">
            <label for="special_event" class="form-label">Special Event</label>
            <input type="text" class="form-control" id="special_event" name="special_event" value="<?php echo $promo['special_event']; ?>" placeholder="Nama Event ..." required>
        </div>

        <div class="mb-3">
            <label for="tempat_promo" class="form-label">Tempat Promo</label>
            <input type="text" class="form-control" id="tempat_promo" name="tempat_promo" value="<?php echo $promo['tempat_promo']; ?>" placeholder="Tempat Promo ..." required>
        </div>

        <div class="mb-3">
            <label for="batas_promo" class="form-label">Batas Promo</label>
            <input type="text" class="form-control" id="batas_promo" name="batas_promo" value="<?php echo $promo['batas_promo']; ?>" placeholder="Batas Promo ..." required>
        </div>

        <button type="submit" name="ubah" class="btn btn-primary" style="float: right;">Ubah</button>
    </form>
</div>

<?php include 'layout/footer.php'; ?>