<?php 
 
include 'config.php';

?>

<!DOCTYPE html>
<html lang="en">

<head>
  <meta charset="utf-8">
  <meta content="width=device-width, initial-scale=1.0" name="viewport">

  <title>DiskonKuyy</title>
  <meta content="" name="description">
  <meta content="" name="keywords">

  <!-- Favicons -->
  <link href="assets/img/logo.png" rel="icon">
  <link href="assets/img/logo.png" rel="apple-touch-icon">

  <!-- Google Fonts -->
  <link href="https://fonts.googleapis.com/css?family=Poppins:300,300i,400,400i,600,600i,700,700i|Satisfy|Comic+Neue:300,300i,400,400i,700,700i" rel="stylesheet">

  <!-- Vendor CSS Files -->
  <link href="assets/vendor/animate.css/animate.min.css" rel="stylesheet">
  <link href="assets/vendor/bootstrap/css/bootstrap.min.css" rel="stylesheet">
  <link href="assets/vendor/bootstrap-icons/bootstrap-icons.css" rel="stylesheet">
  <link href="assets/vendor/boxicons/css/boxicons.min.css" rel="stylesheet">
  <link href="assets/vendor/glightbox/css/glightbox.min.css" rel="stylesheet">
  <link href="assets/vendor/swiper/swiper-bundle.min.css" rel="stylesheet">

  <!-- Template Main CSS File -->
  <link href="assets/css/style.css" rel="stylesheet">

</head>

<body>

  <!-- ======= Header ======= -->
  <header id="header" class="fixed-top d-flex align-items-center header-transparent">
    <div class="container-fluid container-xl d-flex align-items-center justify-content-between">

      <div class="logo me-auto">
		<h1><a href="index.html">DiskonKuyy</a></h1>
      </div>

      <nav id="navbar" class="navbar order-last order-lg-0">
        <ul>
          <li><a class="nav-link scrollto active" href="#hero">Home</a></li>
          <li><a class="nav-link scrollto" href="#about">Tentang</a></li>
          <li><a class="nav-link scrollto" href="#specials">Promo Spesial Event</a></li>
          <li><a class="nav-link scrollto" href="#gallery">Galeri</a></li>
          <li><a class="nav-link scrollto" href="#"></a></li>
        </ul>
        <i class="bi bi-list mobile-nav-toggle"></i>
      </nav><!-- .navbar -->
      <a href="logout.php" class="book-a-table-btn scrollto">Log out</a>
    </div>
  </header><!-- End Header -->

  <!-- ======= Hero Section ======= -->
  <section id="hero">
    <div class="hero-container">
      <div id="heroCarousel" data-bs-interval="5000" class="carousel slide carousel-fade" data-bs-ride="carousel">

        <ol class="carousel-indicators" id="hero-carousel-indicators"></ol>

        <div class="carousel-inner" role="listbox">

          <!-- Slide 1 -->
          <div class="carousel-item active" style="background-image: url(assets/img/slide/slide-1.jpg);">
            <div class="carousel-container">
              <div class="carousel-content">
                <h2 class="animate__animated animate__fadeInDown"><span>Promo</span> Hunting</h2>
                <p class="animate__animated animate__fadeInUp">Membantu para promo hunter untuk mencari diskon dan promo setiap cafe maupun restoran. Menghadirkan fitur untuk mencari cafe maupun restoran yang dicari dengan memilih daerah yang diinginkan.</p>
                <div>
                  <a href="menu.html" class="btn-menu animate__animated animate__fadeInUp scrollto">Lihat Promo</a>
                </div>
              </div>
            </div>
          </div>

          <!-- Slide 2 -->
          <div class="carousel-item" style="background-image: url(assets/img/slide/slide-2.jpg);">
            <div class="carousel-container">
              <div class="carousel-content">
                <h2 class="animate__animated animate__fadeInDown"><span>Promo</span> Hunting</h2>
                <p class="animate__animated animate__fadeInUp">Membantu para promo hunter untuk mencari diskon dan promo setiap cafe maupun restoran. Menghadirkan fitur untuk mencari cafe maupun restoran yang dicari dengan memilih daerah yang diinginkan.</p>
                <div>
                  <a href="menu.html" class="btn-menu animate__animated animate__fadeInUp scrollto">Lihat Promo</a>
                </div>
              </div>
            </div>
          </div>

          <!-- Slide 3 -->
          <div class="carousel-item" style="background-image: url(assets/img/slide/slide-3.jpg);">
            <div class="carousel-container">
              <div class="carousel-content">
                <h2 class="animate__animated animate__fadeInDown"><span>Promo</span> Hunting</h2>
                <p class="animate__animated animate__fadeInUp">Membantu para promo hunter untuk mencari diskon dan promo setiap cafe maupun restoran. Menghadirkan fitur untuk mencari cafe maupun restoran yang dicari dengan memilih daerah yang diinginkan.</p>
                <div>
                  <a href="menu.html" class="btn-menu animate__animated animate__fadeInUp scrollto">Lihat Promo</a>
                </div>
              </div>
            </div>
          </div>

        </div>

        <a class="carousel-control-prev" href="#heroCarousel" role="button" data-bs-slide="prev">
          <span class="carousel-control-prev-icon bi bi-chevron-left" aria-hidden="true"></span>
        </a>

        <a class="carousel-control-next" href="#heroCarousel" role="button" data-bs-slide="next">
          <span class="carousel-control-next-icon bi bi-chevron-right" aria-hidden="true"></span>
        </a>

      </div>
    </div>
  </section><!-- End Hero -->

  <main id="main">

    <!-- ======= About Section ======= -->
    <section id="about" class="about">
      <div class="container-fluid">

        <div class="row">

          <div class="col-lg-5 align-items-stretch video-box" style='background-image: url("assets/img/about.png");'>
            <a href="https://youtu.be/gllEt325suY" class="venobox play-btn mb-4" data-vbtype="video" data-autoplay="true"></a>
          </div>

          <div class="col-lg-7 d-flex flex-column justify-content-center align-items-stretch">

            <div class="content">
              <h3>Tentang DiskonKuyy</strong></h3>
              <p>DiskonKuyy menyediakan website untuk para promo hunter agar dapat mencari informasi promo tempat kuliner yang diinginkan. Tidak perlu repot lagi mengecek satu per satu tempat kuliner untuk mengecek promo yang tersedia. Cukup dengan membuka situs DiskonKuyy, semua promo dari banyaknya tempat kuliner terpercaya di Indonesia sudah siap tersedia. Tinggal pilih kuliner favoritmu.</p>
              <ul>
				<li><i class="bx bx-check-double"></i> Selalu up to date informasi promo diskon setiap tempat kuliner.</li>
                <li><i class="bx bx-check-double"></i> Filterisasi yang unik dan mudah dicari.</li>
                <li><i class="bx bx-check-double"></i> Data selalu valid.</li>
              </ul>
            </div>

          </div>

        </div>

      </div>
    </section><!-- End About Section -->


    <!-- ======= Specials Section ======= -->
    <section id="specials" class="specials">
      <div class="container">

        <div class="section-title">
          <h2>Promo <span>Spesial Event</span></h2>
          <p>Promo berlaku pada setiap Hari Libur Nasional.</p>
        </div>

        <div class="row">
          <div class="col-lg-3">
            <ul class="nav nav-tabs flex-column">
              <li class="nav-item">
                <a class="nav-link active show" data-bs-toggle="tab" href="#tab-1">Tahun Baru Masehi</a>
              </li>
              <li class="nav-item">
                <a class="nav-link" data-bs-toggle="tab" href="#tab-2">Tahun Baru Imlek</a>
              </li>
              <li class="nav-item">
                <a class="nav-link" data-bs-toggle="tab" href="#tab-3">Bulan Ramadhan</a>
              </li>
              <li class="nav-item">
                <a class="nav-link" data-bs-toggle="tab" href="#tab-4">Lebaran Idul Fitri</a>
              </li>
              <li class="nav-item">
                <a class="nav-link" data-bs-toggle="tab" href="#tab-5">Hari Lahir Pancasila</a>
              </li>
              <li class="nav-item">
                <a class="nav-link" data-bs-toggle="tab" href="#tab-6">Lebaran Idul Adha</a>
              </li>
              <li class="nav-item">
                <a class="nav-link" data-bs-toggle="tab" href="#tab-7">Hari Kemerdekaan NKRI</a>
              </li>
              <li class="nav-item">
                <a class="nav-link" data-bs-toggle="tab" href="#tab-8">Natal</a>
              </li>
			</ul>
          </div>
          <div class="col-lg-9 mt-4 mt-lg-0">
            <div class="tab-content">
              <div class="tab-pane active show" id="tab-1">
                <div class="row">
                  <div class="col-lg-8 details order-2 order-lg-1">
                    <h3>Tahun Baru Masehi</h3>
                    <p>Promo tahun baru terbaik setiap tahun datang lagi! Raih semua kode promo dan voucher spesial tahun baru dari berbagai tempat kuliner di seluruh Indonesia. Kalian bisa belanja berbagai kuliner dengan diskon besar-besaran menyambut tahun baru.</p>
					<a href="menu.html" class="book-a-table-btn scrollto">Lihat Promo</a>
				  </div>
                  <div class="col-lg-4 text-center order-1 order-lg-2">
                    <img src="assets/img/specials-1.png" alt="" class="img-fluid">
                  </div>
                </div>
              </div>
              <div class="tab-pane" id="tab-2">
                <div class="row">
                  <div class="col-lg-8 details order-2 order-lg-1">
                    <h3>Tahun Baru Imlek</h3>
                    <p>Aneka diskon dan promo Imlek tersedia secara online di daftar menu DiskonKuyy. Dapatkan berbagai kode promo dan voucher dari berbagai tempat kuliner kesayangan kalian. Nikmati voucher spesial Imlek sepuasnya.</p>
					<a href="menu.html" class="book-a-table-btn scrollto">Lihat Promo</a>
				  </div>
                  <div class="col-lg-4 text-center order-1 order-lg-2">
                    <img src="assets/img/specials-2.png" alt="" class="img-fluid">
                  </div>
                </div>
              </div>
              <div class="tab-pane" id="tab-3">
                <div class="row">
                  <div class="col-lg-8 details order-2 order-lg-1">
                    <h3>Bulan Ramadhan</h3>
                    <p>Berbagai tempat kuliner sudah menyiapkan banyak promo di bulan Ramadhan. Banyak sekali promo yang tersedia untuk kalian agar kalian bisa menikmati sajian Ramadhan yang lebih praktis dan hemat dompet.</p>
					<a href="menu.html" class="book-a-table-btn scrollto">Lihat Promo</a>
                  </div>
                  <div class="col-lg-4 text-center order-1 order-lg-2">
                    <img src="assets/img/specials-3.png" alt="" class="img-fluid">
                  </div>
                </div>
              </div>
              <div class="tab-pane" id="tab-4">
                <div class="row">
                  <div class="col-lg-8 details order-2 order-lg-1">
                    <h3>Lebaran Idul Fitri</h3>
                    <p>Biar Lebaran semakin meriah, jangan lupa cek promo Lebaran dari berbagai tempat kuliner, kalian bisa cek promo maupun diskon terbaik agar Perayaan Lebaran dan silaturahmi tetap maksimal. Pesan kuliner favorit kalian sambil silaturahmi bersama teman dan keluarga.</p>
					<a href="menu.html" class="book-a-table-btn scrollto">Lihat Promo</a>
                  </div>
                  <div class="col-lg-4 text-center order-1 order-lg-2">
                    <img src="assets/img/specials-4.png" alt="" class="img-fluid">
                  </div>
                </div>
              </div>
              <div class="tab-pane" id="tab-5">
                <div class="row">
                  <div class="col-lg-8 details order-2 order-lg-1">
                    <h3>Hari Lahir Pancasila</h3>
                    <p>Di Hari Lahir Pancasila kalian akan ditemani dengan promo makanan dan minuman yang murah meriah. Banyak promo, diskon, dan potongan harga yang menarik dari berbagai restoran dan gerai minuman. Semua promo ini bisa digunakan untuk jajan hemat.</p>
					<a href="menu.html" class="book-a-table-btn scrollto">Lihat Promo</a>
                  </div>
                  <div class="col-lg-4 text-center order-1 order-lg-2">
                    <img src="assets/img/specials-5.png" alt="" class="img-fluid">
                  </div>
                </div>
              </div>
              <div class="tab-pane" id="tab-6">
                <div class="row">
                  <div class="col-lg-8 details order-2 order-lg-1">
                    <h3>Lebaran Idul Adha</h3>
                    <p>Bagi yang hendak mempersiapkan hidangan Lezat pada hari raya Idul Adha. Ada Solusi nih bagi kalian yang mau belanja hemat sebagai tambahan kuliner untuk meramaikan perayaan Idul Adha. Terdapat beragam kuliner menarik yang menawarkan Promo Spesial Idul Adha.</p>
					<a href="menu.html" class="book-a-table-btn scrollto">Lihat Promo</a>
                  </div>
                  <div class="col-lg-4 text-center order-1 order-lg-2">
                    <img src="assets/img/specials-6.png" alt="" class="img-fluid">
                  </div>
                </div>
              </div>
              <div class="tab-pane" id="tab-7">
                <div class="row">
                  <div class="col-lg-8 details order-2 order-lg-1">
                    <h3>Hari Kemerdekaan NKRI</h3>
                    <p>Setiap tanggal 17 Agustus selalu diperingati sebagai Hari Kemerdekaan Indonesia. Dalam memeriahkan HUT NKRI, berbagai tempat kuliner memberikan ragam promo khusus untuk para pelanggan. Belanja semakin hemat dengan diskon yang ditawarkan untuk menyambut HUT NKRI!</p>
					<a href="menu.html" class="book-a-table-btn scrollto">Lihat Promo</a>
                  </div>
                  <div class="col-lg-4 text-center order-1 order-lg-2">
                    <img src="assets/img/specials-7.png" alt="" class="img-fluid">
                  </div>
                </div>
              </div>
              <div class="tab-pane" id="tab-8">
                <div class="row">
                  <div class="col-lg-8 details order-2 order-lg-1">
                    <h3>Natal</h3>
                    <p>Menjelang perayaan natal banyak tempat kuliner yang menawarkan diskon dan promo produk dalam rangka merayakan natal. Jangan lewatkan promo terbaru dan terkeren di hari Natal, mulai dari diskon, cashback, special offer dari berbagai tempat kuliner pilihan.</p>
					<a href="menu.html" class="book-a-table-btn scrollto">Lihat Promo</a>
                  </div>
                  <div class="col-lg-4 text-center order-1 order-lg-2">
                    <img src="assets/img/specials-8.png" alt="" class="img-fluid">
                  </div>
                </div>
              </div>			  
            </div>
          </div>
        </div>

      </div>
    </section><!-- End Specials Section -->

    <!-- ======= Gallery Section ======= -->
    <section id="gallery" class="gallery">
      <div class="container-fluid">

        <div class="section-title">
          <h2>Galeri foto dari <span>Tempat Kuliner</span></h2>
        </div>

        <div class="row g-0">

          <div class="col-lg-3 col-md-4">
            <div class="gallery-item">
              <a href="assets/img/gallery/gallery-1.jpg" class="gallery-lightbox">
                <img src="assets/img/gallery/gallery-1.jpg" alt="" class="img-fluid">
              </a>
            </div>
          </div>

          <div class="col-lg-3 col-md-4">
            <div class="gallery-item">
              <a href="assets/img/gallery/gallery-2.jpg" class="gallery-lightbox">
                <img src="assets/img/gallery/gallery-2.jpg" alt="" class="img-fluid">
              </a>
            </div>
          </div>

          <div class="col-lg-3 col-md-4">
            <div class="gallery-item">
              <a href="assets/img/gallery/gallery-3.jpg" class="gallery-lightbox">
                <img src="assets/img/gallery/gallery-3.jpg" alt="" class="img-fluid">
              </a>
            </div>
          </div>

          <div class="col-lg-3 col-md-4">
            <div class="gallery-item">
              <a href="assets/img/gallery/gallery-4.jpg" class="gallery-lightbox">
                <img src="assets/img/gallery/gallery-4.jpg" alt="" class="img-fluid">
              </a>
            </div>
          </div>

          <div class="col-lg-3 col-md-4">
            <div class="gallery-item">
              <a href="assets/img/gallery/gallery-5.jpg" class="gallery-lightbox">
                <img src="assets/img/gallery/gallery-5.jpg" alt="" class="img-fluid">
              </a>
            </div>
          </div>

          <div class="col-lg-3 col-md-4">
            <div class="gallery-item">
              <a href="assets/img/gallery/gallery-6.jpg" class="gallery-lightbox">
                <img src="assets/img/gallery/gallery-6.jpg" alt="" class="img-fluid">
              </a>
            </div>
          </div>

          <div class="col-lg-3 col-md-4">
            <div class="gallery-item">
              <a href="assets/img/gallery/gallery-7.jpg" class="gallery-lightbox">
                <img src="assets/img/gallery/gallery-7.jpg" alt="" class="img-fluid">
              </a>
            </div>
          </div>

          <div class="col-lg-3 col-md-4">
            <div class="gallery-item">
              <a href="assets/img/gallery/gallery-8.jpg" class="gallery-lightbox">
                <img src="assets/img/gallery/gallery-8.jpg" alt="" class="img-fluid">
              </a>
            </div>
          </div>
        </div>
      </div>
	    
      <div class="map">
        <iframe src="https://www.google.com/maps/embed?pb=!1m18!1m12!1m3!1d32654820.88251219!2d117.88879999999999!3d-2.4456499999999997!2m3!1f0!2f0!3f0!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0x2c4c07d7496404b7%3A0xe37b4de71badf485!2sIndonesia!5e0!3m2!1sen!2sid!4v1664171492442!5m2!1sen!2sid" width="100%" height="350px" style="border:0;" allowfullscreen="" loading="lazy" referrerpolicy="no-referrer-when-downgrade"></iframe>
      </div>
	    
    </section><!-- End Gallery Section -->

  </main><!-- End #main -->

  <!-- ======= Footer ======= -->
  <footer id="footer">
    <div class="container">
      <h3>DiskonKuyy</h3>
      <p>Membantu para promo hunter untuk menemukan promo disetiap kuliner yang diinginkan.</p>
      <div class="social-links">
        <a href="#" class="twitter"><i class="bx bxl-twitter"></i></a>
        <a href="#" class="facebook"><i class="bx bxl-facebook"></i></a>
        <a href="#" class="instagram"><i class="bx bxl-instagram"></i></a>
        <a href="#" class="google-plus"><i class="bx bxl-skype"></i></a>
        <a href="#" class="linkedin"><i class="bx bxl-linkedin"></i></a>
      </div>
      <div class="copyright">
        &copy; Copyright <strong><span>2022</span></strong>. All Rights Reserved
      </div>
      <div class="credits">
        Designed by Bosses Team
      </div>
    </div>
  </footer><!-- End Footer -->

  <a href="#" class="back-to-top d-flex align-items-center justify-content-center"><i class="bi bi-arrow-up-short"></i></a>

  <!-- Vendor JS Files -->
  <script src="assets/vendor/bootstrap/js/bootstrap.bundle.min.js"></script>
  <script src="assets/vendor/glightbox/js/glightbox.min.js"></script>
  <script src="assets/vendor/isotope-layout/isotope.pkgd.min.js"></script>
  <script src="assets/vendor/swiper/swiper-bundle.min.js"></script>
  <script src="assets/vendor/php-email-form/validate.js"></script>

  <!-- Template Main JS File -->
  <script src="assets/js/main.js"></script>

</body>

</html>
