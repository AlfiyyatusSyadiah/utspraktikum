<?php

include 'config/app.php';

$id_promo = (int)$_GET['id_promo'];

if (delete_promo($id_promo) > 0){
     echo "<script>
            alert('Data Promo Berhasil Dihapus');
            document.location.href = 'index.php';
          </script>";
} else{
    echo "<script>
            alert('Data Promo Gagal Dihapus');
            document.location.href = 'index.php';
          </script>";
}
