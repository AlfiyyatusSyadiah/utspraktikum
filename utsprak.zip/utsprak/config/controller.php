<?php

// fungsi menampilkan
function select($query)
{
    // psnggil koneksi database
    global $db;

    $result = mysqli_query($db, $query);
    $rows = [];

    while ($row = mysqli_fetch_assoc($result)) {
        $rows[] = $row;
    }

    return $rows;
}

// fungsi menambahkan
function create_promo($post)
{
    global $db;

    $nama_promo = $post['nama_promo'];
    $special_event = $post['special_event'];
    $tempat_promo = $post['tempat_promo'];
    $batas_promo = $post['batas_promo'];

    //query tambah data promo
    $query = "INSERT INTO promo VALUES(null, '$nama_promo', '$special_event', '$tempat_promo', '$batas_promo')";

    mysqli_query($db, $query);

    return mysqli_affected_rows($db);
}

// fungsi mengubah data promo
function update_promo($post)
{
    global $db;

    $id_promo       = $post['id_promo'];
    $nama_promo     = $post['nama_promo'];
    $special_event  = $post['special_event'];
    $tempat_promo   = $post['tempat_promo'];
    $batas_promo    = $post['batas_promo'];

    //query ubah data
    $query = "UPDATE promo SET nama_promo = '$nama_promo', special_event = '$special_event', tempat_promo = '$tempat_promo', batas_promo = '$batas_promo' WHERE id_promo = $id_promo";

    mysqli_query($db, $query);

    return mysqli_affected_rows($db);
}

// fungsi menghapus data promo
function delete_promo($id_promo)
{
    global $db;

    //query hapus data promo
    $query = "DELETE FROM promo WHERE id_promo = $id_promo";

    mysqli_query($db, $query);

    return mysqli_affected_rows($db);
}