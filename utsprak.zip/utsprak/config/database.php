<?php

$db = mysqli_connect('localhost', 'root', '', 'diskonkuyy');

//if (!$db) {
//    echo 'gagal' ; 
//} else {
//    echo 'berhasil' ;
//}
